# CS50 – C Projects

مجموعة مشاريع لغة C اللي سويتها أثناء دورة CS50، مرتبة حسب الأسبوع/الموضوع.

## المشاريع

| المشروع | الوصف | المهارات |
|---|---|---|
| [Hello](./week1-hello) | برنامج ترحيب بسيط | أساسيات C |
| [Readability](./week2-arrays) | حساب مستوى صعوبة نص | Loops, Strings |
| [Sort](./week3-algorithms) | تطبيق خوارزميات الفرز | Algorithms |
| [Filter](./week4-memory) | تعديل صور PPM | Arrays, Memory |
| [Speller](./week5-data-structures) | مدقق إملائي بجدول هاش | Data Structures, Pointers |

## كيف تشغل أي مشروع

```bash
cd اسم-المجلد
gcc اسم_الملف.c -o اسم_الملف
./اسم_الملف
```

## عن هذا الريبو

جزء من رحلتي التعليمية في CS50، ضمن دراستي في دبلوم الذكاء الاصطناعي.
