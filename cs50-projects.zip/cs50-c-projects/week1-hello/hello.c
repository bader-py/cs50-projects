// ضع كود مشروع Hello هنا
#include <stdio.h>

int main(void)
{
    printf("Hello, world!\n");
}
