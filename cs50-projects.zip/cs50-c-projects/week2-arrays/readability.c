// ضع كود مشروع Readability هنا
#include <stdio.h>

int main(void)
{
    // TODO
}
