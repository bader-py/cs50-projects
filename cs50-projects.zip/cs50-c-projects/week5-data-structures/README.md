# Speller

مدقق إملائي يستخدم جدول هاش (Hash Table) للتحقق من تهجئة الكلمات بسرعة.

## الوصف
يحمّل قاموس كبير في الذاكرة، يتحقق من نص، ويحسب زمن التنفيذ.

## التشغيل
```bash
gcc -o speller speller.c dictionary.c -lm
./speller dictionaries/large text.txt
```
