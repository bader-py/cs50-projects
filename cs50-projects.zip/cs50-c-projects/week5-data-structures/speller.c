// ضع كود مشروع Speller هنا
#include <stdio.h>

int main(void)
{
    // TODO
}
