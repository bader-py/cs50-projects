// ضع كود مشروع Sort هنا
#include <stdio.h>

int main(void)
{
    // TODO
}
