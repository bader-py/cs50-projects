# Sort

تطبيق وتحليل خوارزميات الفرز (Bubble Sort / Merge Sort / Selection Sort).

## الوصف
مقارنة أداء عدة خوارزميات فرز على مصفوفات بأحجام مختلفة.

## التشغيل
```bash
gcc sort.c -o sort
./sort
```
