// ضع كود مشروع Filter هنا
#include <stdio.h>

int main(void)
{
    // TODO
}
