# Filter

برنامج يطبّق فلاتر (Grayscale, Sepia, Blur, Edges) على صور بصيغة BMP.

## الوصف
يوضح فهم إدارة الذاكرة والمصفوفات ثنائية الأبعاد في C.

## التشغيل
```bash
gcc -o filter filter.c helpers.c -lm
./filter -g input.bmp output.bmp
```
